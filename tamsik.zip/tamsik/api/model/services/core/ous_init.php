<?php

session_start();

$GLOBALS['config'] = array(

	 'mysql' => array(
       'host' => 'localhost',
       'username' => 'root',
       'password' => '',
       'db'=>'tamsik'
      ),
     'remember' => array(
       'cookie_name' => 'hash',
       'cookie_expiry' => '604800'
     ),
	 'session' => array(
       'session_name' => 'username',
       'token_name'=>'token'
	 )
);

spl_autoload_register(function($class)
{
	require_once '../model/services/classes/'.$class.'.php';
});

require_once '../model/services/functions/ous_Sanitize.php';

if(ous_Cookie::exists(ous_Config::get('remember/cookie_name')) && !ous_Session::exists(ous_Config::get('session/session_name')))
{
    //echo 'User asked to be remembered';

   $hash = ous_Cookie::get(ous_Config::get('remember/cookie_name'));

    $hashCheck = ous_DB::getInstance()->get('clients_session', array('hash', '=', $hash));

      if($hashCheck->count())
      {
        //echo 'Hash matches, logged user in.';
        $user = new ous_User($hashCheck->first()->user_id);
        $user->login();
      }
  }