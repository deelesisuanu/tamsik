<?php
class ous_Token
{
	public static function generate()
	{
		return ous_Session::put(ous_Config::get('session/token_name'),md5(uniqid()));
	}

	public static function check($token)
	{
        $tokenName = ous_Config::get('session/token_name');
        
        if(ous_Session::exists($tokenName) && $token === ous_Session::get($tokenName))
    	{
    		ous_Session::delete($tokenName);
    		return true;
    	}
    	return false;

	}
}

?>