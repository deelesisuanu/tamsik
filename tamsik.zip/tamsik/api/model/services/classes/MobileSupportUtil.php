<?php

class MobileSupportUtil
{
	function getUserAgent()
	{
		$userAgent = strtolower($_SERVER['HTTP_USER_AGENT']);
		return $userAgent;
	}
	function getAcceptHeader()
	{
		$acceptHeader = strtolower($_SERVER['HTTP_ACCEPT']);
		return $acceptHeader;
	}
	function getWapProfile()
	{
		$wapProfile = strtolower($_SERVER['HTTP_X_WAP_PROFILE']);
		return $wapProfile;
	}
	function getHttpProfile()
	{
		$httpProfile = strtolower($_SERVER['HTTP_PROFILE']);
		return $httpProfile;
	}

	function isMobileDevice()
	{
		$userAgent = $this->getUserAgent();
		$acceptHeader = $this->getAcceptHeader();
		// $wapProfile = $this->getWapProfile();
		// $httpProfile = $this->getHttpProfile();

		$checkMobile = false;

		$mobileDeviceList = array('w3c ','acs-','alav','alca','amoi','audi','avan','benq','bird','blac',
    'blaz','brew','cell','cldc','cmd-','dang','doco','eric','hipt','inno',
    'ipaq','java','jigs','kddi','keji','leno','lg-c','lg-d','lg-g','lge-',
    'maui','maxo','midp','mits','mmef','mobi','mot-','moto','mwbp','nec-',
    'newt','noki','palm','pana','pant','phil','play','port','prox',
    'qwap','sage','sams','sany','sch-','sec-','send','seri','sgh-','shar',
    'sie-','siem','smal','smar','sony','sph-','symb','t-mo','teli','tim-',
    'tosh','tsm-','upg1','upsi','vk-v','voda','wap-','wapa','wapi','wapp',
    'wapr','webc','winw','winw','xda ','xda-');
	

	switch(true)
	{
	  case(strpos($userAgent, 'ipod') !== false);
	  $checkMobile = 'iPod';
	  break;

	  case(strpos($userAgent, 'iPhone') !== false);
	  $checkMobile = 'iPhone';
	  break;

	  case(strpos($userAgent, 'android') !== false);
	  $checkMobile = 'android';
	  break;

	  case(strpos($userAgent, 'blackberry') !== false);
	  $checkMobile = 'blackberry';
	  break;

	  case(strpos($userAgent, 'webos') !== false);
	  $checkMobile = 'Webos';
	  break;

	  case(preg_match('/(up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone|android|iemobile)/i', $userAgent));
	  $checkMobile = 'Generic';
	  break;

	  case(in_array(substr($userAgent,0,4), $mobileDeviceList));
	  $checkMobile = 'Generic';
	  break;

	  case(strpos($acceptHeader, 'wap') !== false || strpos($acceptHeader, 'wml')!== false);
	  $checkMobile = 'unknown';
	  break;

	  // case($wapProfile != null || $httpProfile != null);
	  // $checkMobile = 'unknown';
	  // break;


	}
	return $checkMobile;
  }

}

?>