<?php

class ous_User
{
    private $_db;
    private $_data;
    private $_sessionName;
    private $_isLoggedIn;
    private $_cookieName;

    public function __construct($user = null)
    {
        $this->_db = ous_DB::getInstance();

        $this->_sessionName = ous_Config::get('session/session_name');
        $this->_cookieName = ous_Config::get('remember/cookie_name');

        if (!$user) {
            if (ous_Session::exists($this->_sessionName)) {
                $user = ous_Session::get($this->_sessionName);

                if ($this->find($user)) {
                    $this->_isLoggedIn = true;
                } else {
                    self::logout();
                }
            }
        } else {
            $this->find($user);
        }
    }
    public function update($fields = array(), $id = null)
    {
        if (!$id && $this->isLoggedIn()) {
            $id = $this->data()->id;
        }

        if (!$this->_db->update('clients', $id, $fields)) {
            throw new Exception('Error Encountered while Updating');
        }
    }

    public function create($fields=array())
    {
        if (!$this->_db->insert('clients', $fields)) {
            throw new Exception('There was a problem creating an account');
        }
    }
    public function find($user = null)
    {
        if ($user) {
            $field = (is_numeric($user)) ? 'id' : 'username';
            $data = $this->_db->get('clients', array($field, '=', $user));

            if ($data->count()) {
                $this->_data = $data->first();

                return true;
            }
        }
        return false;
    }

    public function pull($mode, $table)
    {
        return $this->_db->get_($mode, $table);
    }

    public function pulled($mode, $table)
    {
        $data = $this->_db->get_($mode, $table);
        if ($data->count()) {
          return $this->data()->id;
        }
    }
    
    public function app_login($username = null)
    {
        $user = $this->find($username);
      
        if (!$username && $this->exists()) {
            //log user in
            ous_Session::put($this->_sessionName, $this->data()->id);
        } else {
            if ($user) {
                $check = $this->_db->get('clients_session', array('user_id', '=', $this->data()->id));
                if ($check->count()) {
                    self::logout();
                } else {
                    ous_Session::put($this->_sessionName, $this->data()->id);
                    $hash = ous_Hash::unique();
                    //$db = ous_DB::getInstance();
                    $hashCheck = $this->_db->get('clients_session', array('user_id', '=', $this->data()->id));
                    //$db->get('clients_session', array('user_id', '=', $this->data()->id));
    
                    if (!$hashCheck->count()) {
                        $this->_db->insert('clients_session', array(
                        'user_id'=>$this->data()->id,
                        'hash'=>$hash
                    ));
                    } else {
                        $hash = $hashCheck->first()->hash;
                    }
                    ous_Cookie::put($this->_cookieName, $hash, ous_Config::get('remember/cookie_expiry'));
                    return true;
                }
            } else {
                echo 34;
            }
        }
      
        return false;
    }

    public function login($username = null, $password = null, $remember = false)
    {
        $user = $this->find($username);

        if (!$username && !$password && $this->exists()) {
            //log user in
            ous_Session::put($this->_sessionName, $this->data()->id);
        } else {
            if ($user) {
                $check = $this->_db->get('clients_session', array('user_id', '=', $this->data()->id));
                if ($check->count()) {
                    self::logout();
                } else {
                    if ($this->data()->password === ous_Hash::make($password, $this->data()->salt)) {
                        ous_Session::put($this->_sessionName, $this->data()->id);

                        $hash = ous_Hash::unique();
                        //$db = ous_DB::getInstance();
                        $hashCheck = $this->_db->get('clients_session', array('user_id', '=', $this->data()->id));
                        //$db->get('clients_session', array('user_id', '=', $this->data()->id));

                        if (!$hashCheck -> count()) {
                            $this->_db->insert('clients_session', array(
                       'user_id'=>$this->data()->id,
                       'hash'=>$hash
                     ));
                        } else {
                            $hash = $hashCheck->first()->hash;
                        }
                        ous_Cookie::put($this->_cookieName, $hash, ous_Config::get('remember/cookie_expiry'));
                        return true;
                    }
                }
            }
        }
        return false;
    }

    // public function hasPermission($key)
    // {
    //   $group = $this->_db->get('grouped', array('id', '=', $this->data()->grouped));

    //   if($group->count())
    //   {
    //     $permission = json_decode($group->first()->permission, true);

    //     if($permission[$key] == true)
    //     {
    //       return true;
    //     }
    //   }
    //   return false;
    // }

    public function exists()
    {
        return (!empty($this->_data)) ? true : false;
    }


    public function logout()
    {
        $this->_db->delete('clients_session', array('user_id', '=', $this->data()->id));

        ous_Session::delete($this->_sessionName);
        ous_Cookie::delete($this->_cookieName);
    }

    public function data()
    {
        return $this->_data;
    }
    public function isLoggedIn()
    {
        return $this->_isLoggedIn;
    }
    public function hash()
    {
        return $this->_hash;
    }
}
