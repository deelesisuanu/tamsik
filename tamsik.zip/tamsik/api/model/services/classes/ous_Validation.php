<?php
class ous_Validation
{
    private $_passed = false;
    private $_errors = array();
    private $_db = null;


    public function __construct()
    {
        $this->_db = ous_DB::getInstance();
    }

    public function check($source, $items=array())
    {
        foreach ($items as $item => $rules) {
            foreach ($rules as $rule => $rule_values) {
                $value = trim($source[$item]);
                $item = escape($item);
                 
                if ($rule === 'required' && empty($value)) {
                    $this->addError("{$item} is required");
                } elseif (!empty($value)) {
                    switch ($rule) {
                       case 'min':
                             if (strlen($value) < $rule_values) {
                                 $this->addError("{$item} must be a minimum of {$rule_values} characters");
                             }
                           break;

                       case 'max':
                             if (strlen($value) > $rule_values) {
                                 $this->addError("{$item} must be a maximum of {$rule_values} characters");
                             }
                           break;

                       case 'same':
                             if ($value != $source[$rule_values]) {
                                 $this->addError("{$rule_values} must match {$item}");
                             }
                           break;
                       case 'matches':
                             if ($value != $rule_values) {
                                 $this->addError("{$item} must contan '@', and a '.'  ");
                             }
                             break;

                        case 'matchesN':
                             if ($value != $rule_values) {
                                 $this->addError("{$item} must be of type alpha_numeric");
                             }
                             break;

                      case 'matchesPhone':
                          if ($value != $rule_values) {
                              $this->addError("{$item} must be of type digit");
                          }
                          // no break
                        case 'nameMatch':
                             if ($value != $rule_values) {
                                 $this->addError("{$item} must consist of letters only");
                             }
                             break;
                      case 'unique':
                            $check = $this->_db->get('clients', array($item, '=', $value));
                            if ($check->count()) {
                                $this->addError("{$item} already exists");
                            }
                            break;
                       
                       default:
                           break;
                   }
                }
            }
        }
        if (empty($this->_errors)) {
            $this->_passed = true;
        }
        return $this;
	}
	
    private function addError($error)
    {
        $this->_errors[] = $error;
    }
    public function errors()
    {
        return $this->_errors;
    }
    public function passed()
    {
        return $this->_passed;
    }
}
