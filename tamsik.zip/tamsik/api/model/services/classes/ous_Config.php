<?php

class ous_Config
{
	public static function get($ous_path = null)
	{
		if($ous_path)
		{
			$ous_config = $GLOBALS['config'];
			$ous_path = explode('/', $ous_path);

			foreach ($ous_path as $bit)
			{
				if(isset($ous_config[$bit]))
				{
					$ous_config = $ous_config[$bit];
				}
				
			}
			return $ous_config;
		}
		return false;
	}
}