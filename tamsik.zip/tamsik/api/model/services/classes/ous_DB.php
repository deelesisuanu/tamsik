<?php

class ous_DB
{
	private static $_ous_instance = null;
	private $_ous_pdo,
	$_ous_query,
	$_ous_results,
	$_ous_count = 0;
	private $ous_error;


	private function __construct()
	{
		try
		{
			$this->ous_pdo = new PDO('mysql:host ='. ous_Config::get('mysql/host'). ';dbname='.ous_Config::get('mysql/db'), ous_Config::get('mysql/username'), ous_Config::get('mysql/password'));
		}
		catch(PDOException $ex)
		{
			die($ex->getMessage());
		}
	}

	public static function getInstance()
	{
		if(!isset(self::$_ous_instance))
		{
			self::$_ous_instance = new ous_DB();
		}
		return self::$_ous_instance;
	}

	public function query($ous_sql, $ous_params=array())
	{
		$this->ous_error = false;
		if($this->ous_query = $this->ous_pdo->prepare($ous_sql))
		{
			$x = 1;
			if(count($ous_params))
			{
				foreach ($ous_params as $ous_param)
				{
				 	$this->ous_query->bindValue($x, $ous_param);
				 	$x++;
				}
			}
			if($this->ous_query->execute())
            {
        	  $this->ous_results = $this->ous_query->fetchAll(PDO::FETCH_OBJ);
        	  $this->ous_count = $this->ous_query->rowCount();
            }
            else
            {
            	$this->ous_error = true;
            }
		}
		return $this;
	}
	
	public function action($ous_action, $ous_table, $ous_where = array())
	{
        if(count($ous_where === 3))
        {
        	$ous_operators = array('=', '>', '<', '>=', '<=');

        	$ous_field       = $ous_where[0];
        	$ous_operator    = $ous_where[1];
        	$ous_value       = $ous_where[2];

        	if(in_array($ous_operator, $ous_operators))
        	{
                $ous_sql = "{$ous_action} FROM {$ous_table} WHERE {$ous_field} {$ous_operator} ?";
                if(!$this->query($ous_sql, array($ous_value))->error())
                {
                     return $this;
                }
        	}
        }
        return false;
	}
	
	public function action_($ous_action, $ous_table)
	{
		$ous_sql = "{$ous_action} FROM {$ous_table}";
        if($this->query($ous_sql))
        {
			return $this;
        }
        return false;
	}
	
	public function get_($mode, $ous_table)
	{
        return $this->action_($mode, $ous_table);
	}

	public function get($ous_table, $ous_where)
	{
        return $this->action('SELECT *', $ous_table, $ous_where);
	}
	public function delete($ous_table, $ous_where)
	{
        return $this->action('DELETE', $ous_table, $ous_where);
	}
	public function results()
	{
		return $this->ous_results;
	}
	public function insert($ous_table, $ous_fields = array())
	{
		if(count($ous_fields))
		{
            $ous_keys = array_keys($ous_fields);
            $ous_values = '';
            $x =1;

            foreach($ous_fields as $ous_field)
            {
            	$ous_values.= '?';
            	if($x < count($ous_fields))
            	{
            		$ous_values.=', ';
            	}
            	$x++; 
            }
            // die($ous_values);

            $ous_sql = "INSERT INTO {$ous_table} (`" .implode('`, `', $ous_keys) . "`) VALUES({$ous_values})" ;

            // echo $ous_sql; 
            if(!$this->query($ous_sql, $ous_fields)->error())
            {
            	return true;
            }
		} 
		return false;
	}
	public function update($ous_table, $ous_id, $ous_fields)
	{
		$set = '';
		$x = 1;
		foreach ($ous_fields as $field => $value) 
		{
			$set .= "{$field} = ?";

			if($x < count($ous_fields))
			{
				$set .= ',';
			}
			$x++;
			
		}
		// die($set);
		$ous_sql = "UPDATE {$ous_table} SET {$set} WHERE id = {$ous_id}";

		// echo $ous_sql;

		if(!$this->query($ous_sql, $ous_fields)->error())
        {
           return true;
        }
        
         return false;
	}
	
	public function first()
	{
		return $this->results()[0];
	}
	public function error()
	{
		return $this->ous_error;
	}
	public function count()
	{
		return $this->ous_count;
	}
}