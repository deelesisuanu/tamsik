<?php

require_once '../model/services/core/ous_init.php';

$user = new ous_User();

$mode = ous_Input::get('mode');
$table = ous_Input::get('table');

$data_all = $user->pull($mode, $table);

$data = array();;

foreach ($data_all as $key => $value) {
    array_push($data, json_encode($value));
}

echo json_encode($data);
