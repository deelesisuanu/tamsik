<?php

require_once '../model/services/core/ous_init.php';

function crypto_rand_secure($min, $max)
{
    $range = $max - $min;
    if ($range < 1) {
        return $min;
    } // not so random...
    $log = ceil(log($range, 2));
    $bytes = (int) ($log / 8) + 1; // length in bytes
    $bits = (int) $log + 1; // length in bits
    $filter = (int) (1 << $bits) - 1; // set all lower bits to 1
    do {
        $rnd = hexdec(bin2hex(openssl_random_pseudo_bytes($bytes)));
        $rnd = $rnd & $filter; // discard irrelevant bits
    } while ($rnd > $range);
    return $min + $rnd;
}

if (ous_Input::exists()) {

    $validate = new ous_Validation();
    $validation = $validate->check($_POST, array(

          'fullname'=>array(
            'required'=>true,
            'min'=>5,
            'max'=>35,
            'matchesN'=>preg_match('/[^a-z-0-9]/i', $_POST['fullname'])
          ),

          'guest_id'=>array(
            'required'=>true,
            'min'=>5,
          ),

          'email_address' =>array(
            'required' =>true,
            'unique'=>'clients',
            'min' =>6,
            'matches' =>filter_var($_POST['email_address'], FILTER_VALIDATE_EMAIL),
           ),

           'phone' =>array(
            'required'=>true,
            'max'=> 11,
            'min'=>11,
            'matchesPhone'=> $_POST['phone'],
          ),

          'nok' =>array(
            'required'=>true,
          ),

          'identity' =>array(
            'required'=>true,
          ),

          'num_nights' =>array(
            'required'=>true,
            'matchesPhone'=> $_POST['num_nights'],
          ),

          'num_rooms' =>array(
            'required'=>true,
            'matchesPhone'=> $_POST['num_rooms'],
          ),

          'date_arrival' =>array(
            'required'=>true,
          ),

          'arrival_time' =>array(
            'required'=>true,
          ),

          'departure_date' =>array(
            'required'=>true,
          ),

          'departure_time' =>array(
            'required'=>true,
          ),

          'room_num' =>array(
            'required'=>true,
          ),

          'check_in_staff' =>array(
            'required'=>true,
          ),

          'num_company' =>array(
            'required'=>true,
          ),

          'payment_means' =>array(
            'required'=>true,
          ),

          'room_type' =>array(
            'required'=>true,
          ),

          'amount_paid' =>array(
            'required'=>true,
          ),

      )
    );

    if ($validation->passed()) {
        $user = new ous_User();
        
        $rnk = crypto_rand_secure(999, 99999999999);

        $salt = ous_Hash::salt(32);
        
        $fullname = ous_Input::get('fullname');
        $guest_id = ous_Input::get('guest_id');
        $email_address = ous_Input::get('email_address');
        $phone = ous_Input::get('phone');
        $nok = ous_Input::get('nok');
        $identity = ous_Input::get('identity');
        $num_nights = ous_Input::get('num_nights');
        $num_rooms = ous_Input::get('num_rooms');
        $date_arrival = ous_Input::get('date_arrival');
        $arrival_time = ous_Input::get('arrival_time');
        $departure_date = ous_Input::get('departure_date');
        $departure_time = ous_Input::get('departure_time');
        $room_num = ous_Input::get('room_num');
        $check_in_staff = ous_Input::get('check_in_staff');
        $num_company = ous_Input::get('num_company');
        $payment_means = ous_Input::get('payment_means');
        $room_type = ous_Input::get('room_type');
        $amount_paid = ous_Input::get('amount_paid');
        
        $user->create(array(
            'fullname' => $fullname,
            'guest_id' => $guest_id,
            'email_address' => $email_address,
            'phone' => $phone,
            'nok' => $nok,
            'identity' => $identity,
            'num_nights' => $num_nights,
            'num_rooms' => $num_rooms,
            'date_arrival' =>$date_arrival,
            'arrival_time' => $arrival_time,
            'departure_date' => $departure_date,
            'departure_time' => $departure_time,
            'room_num' => $room_num,
            'check_in_staff' => $check_in_staff,
            'num_company' => $num_company,
            'payment_means' => $payment_means,
            'room_type' => $room_type,
            'amount_paid' => $amount_paid
      ));
      echo "success";
    }
    else {
        foreach ($validation->errors() as $error) {
            echo $error;
        }
    }

}
