-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2019 at 01:33 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tamsik`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `fullname` varchar(150) NOT NULL COMMENT 'Full Name (First Name, Last Name)',
  `guest_id` text NOT NULL COMMENT 'Guest ID',
  `email_address` text NOT NULL,
  `phone` int(11) NOT NULL,
  `nok` varchar(95) NOT NULL COMMENT 'Next of Kin (Emergency Contact Number)',
  `identity` varchar(80) NOT NULL COMMENT 'Identification type',
  `num_nights` int(11) NOT NULL COMMENT 'Number of Nights',
  `num_rooms` int(11) NOT NULL COMMENT 'Number of Rooms',
  `date_arrival` date NOT NULL,
  `arrival_time` time NOT NULL,
  `departure_date` date NOT NULL,
  `departure_time` time NOT NULL,
  `room_num` int(11) NOT NULL,
  `check_in_staff` int(11) NOT NULL COMMENT 'Check-In Staff (Employee ID)',
  `num_company` int(11) NOT NULL,
  `payment_means` varchar(85) NOT NULL COMMENT 'Means of Payment (POS, Online Banking, Cash)',
  `room_type` varchar(75) NOT NULL,
  `amount_paid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `emp_check_in`
--

CREATE TABLE `emp_check_in` (
  `id` int(11) NOT NULL,
  `login_time` time NOT NULL COMMENT 'Login Time',
  `login_location` text NOT NULL COMMENT 'Login Location',
  `login_date` date NOT NULL COMMENT 'Login Date',
  `logout_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Logout Time'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL,
  `guest_id` int(11) NOT NULL COMMENT 'Guest ID',
  `feedback` text NOT NULL COMMENT 'Guest''s Feedback',
  `ratings` int(11) NOT NULL COMMENT 'Guest''s Ratings',
  `time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`id`, `guest_id`, `feedback`, `ratings`, `time_stamp`) VALUES
(1, 87, 'Hello am good', 8, '2019-07-22 10:35:55');

-- --------------------------------------------------------

--
-- Table structure for table `hr_management`
--

CREATE TABLE `hr_management` (
  `id` int(11) NOT NULL,
  `emp_id` text NOT NULL,
  `emp_name` varchar(150) NOT NULL,
  `emp_dob` date NOT NULL COMMENT 'Date of Birth',
  `emp_identity` varchar(85) NOT NULL COMMENT 'Identification Type',
  `emp_nok` varchar(70) NOT NULL COMMENT 'Next of Kin',
  `emp_emergency_contact` text NOT NULL COMMENT 'Emergency Contact',
  `emp_phone` int(11) NOT NULL COMMENT 'Phone Number',
  `emp_join_date` date NOT NULL COMMENT 'Join Date',
  `emp_departure` date NOT NULL COMMENT 'Departure Date',
  `emp_salary` int(11) NOT NULL COMMENT 'Employee Salary',
  `emp_acct_num` text NOT NULL COMMENT 'Account Number',
  `emp_shorty` varchar(150) NOT NULL COMMENT 'Shorty',
  `emp_mail` text NOT NULL COMMENT 'Email Address',
  `emp_home_address` text NOT NULL COMMENT 'Home Address',
  `emp_security_pin` text NOT NULL COMMENT 'Security Pin'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `prod_name` varchar(150) NOT NULL COMMENT 'Product Name',
  `prod_price` int(11) NOT NULL COMMENT 'Product Price',
  `prod_qty` int(11) NOT NULL COMMENT 'Product Quantity',
  `prod_stock` int(11) NOT NULL COMMENT 'Product Stock/Unit Price',
  `prod_sales` int(11) NOT NULL COMMENT 'Product Sales',
  `sold_qty` int(11) NOT NULL COMMENT 'Sold Qty Per Day (Auto)',
  `prod_sp` int(11) NOT NULL COMMENT 'Product Sales Price',
  `prod_arrival` date NOT NULL COMMENT 'Product Arrival Date',
  `prod_arrival_time` time NOT NULL COMMENT 'Product Arrival Timestamp'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emp_check_in`
--
ALTER TABLE `emp_check_in`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hr_management`
--
ALTER TABLE `hr_management`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `emp_check_in`
--
ALTER TABLE `emp_check_in`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hr_management`
--
ALTER TABLE `hr_management`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
